<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(url('bootstrap/bootstrap.min.css')); ?>" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Document</title>

    <link rel="stylesheet" href="<?php echo e(url('global.css')); ?>">
</head>

<body>

    <nav class="border-bottom shadow-sm p-3">
      <div class="container-fluid p-1 d-flex justify-content-between">
        <a class="text-decoration-none text-black" href="<?php echo e(url('')); ?>">Aplikasi Perpustakaan</a>
        <div>
          <ul class="d-flex m-0 gap-4 list-unstyled pe-4 my-navbar">
            <li>
              <a class="text-black text-decoration-none" href="<?php echo e(route('buku.index')); ?>">Buku</a>
            </li>
            <li>
              <a class="text-black text-decoration-none" href="<?php echo e(route('jurnal.index')); ?>">Jurnal</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container py-3">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
    




    <script src="<?php echo e(url('bootstrap/bootstrap.bundle.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\Git Projects\aplikasi_perpustakaan\resources\views/layouts/index.blade.php ENDPATH**/ ?>