

<?php $__env->startSection('content'); ?>
    <p class="text-center lead mt-5 pt-5">Selamat datang pada aplikasi perpustakaan!</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Projects\aplikasi_perpustakaan\resources\views/welcome.blade.php ENDPATH**/ ?>