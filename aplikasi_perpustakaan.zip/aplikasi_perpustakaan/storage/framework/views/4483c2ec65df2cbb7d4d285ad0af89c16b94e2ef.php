

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('jurnal.update', ['jurnal' => $jurnal->id])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="card mb-4">
            <div class="card-body">
                <h6 class="card-title mb-3">Edit Jurnal</h6>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="judul">Judul</label>
                            <input class="form-control" value="<?php echo e(old('judul') ? old('judul') : $jurnal->judul); ?>"
                                type="text" name="judul" id="judul" placeholder="Masukkan Judul">
                            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($errors->first('judul')); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="tahun">Tahun</label>
                            <input class="form-control" value="<?php echo e(old('tahun') ? old('tahun') : $jurnal->tahun); ?>"
                                type="number" name="tahun" id="tahun" placeholder="Masukkan Tahun">
                            <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($errors->first('tahun')); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="institusi">Institusi</label>
                            <input class="form-control"
                                value="<?php echo e(old('institusi') ? old('institusi') : $jurnal->institusi); ?>" type="text"
                                name="institusi" id="institusi" placeholder="Masukkan Institusi">
                            <?php $__errorArgs = ['institusi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($errors->first('institusi')); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="peneliti">Peneliti</label>
                            <input class="form-control" value="<?php echo e(old('peneliti') ? old('peneliti') : $jurnal->peneliti); ?>"
                                type="number" name="peneliti" id="peneliti" placeholder="Masukkan Peneliti">
                            <?php $__errorArgs = ['peneliti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($errors->first('peneliti')); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <input class="form-control"
                                value="<?php echo e(old('deskripsi') ? old('deskripsi') : $jurnal->deskripsi); ?>" type="text"
                                name="deskripsi" id="deskripsi" placeholder="Masukkan Deskripsi">
                            <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($errors->first('deskripsi')); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <a href="<?php echo e(route('jurnal.index')); ?>" class="btn btn-outline-secondary mt-4">Kembali</a>
                <button class="btn btn-warning text-white mt-4">Edit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Projects\aplikasi_perpustakaan\resources\views/jurnal/edit.blade.php ENDPATH**/ ?>