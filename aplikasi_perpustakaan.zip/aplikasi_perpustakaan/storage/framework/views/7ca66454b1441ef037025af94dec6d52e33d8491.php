

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('buku.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="card mb-4">
            <div class="card-body">
                <h6 class="card-title mb-3">Tambah Buku</h6>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="judul">Judul</label>
                            <input class="form-control" value="<?php echo e(old('judul')); ?>" type="text" name="judul"
                                id="judul" placeholder="Masukkan Judul">
                            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($errors->first('judul')); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="penerbit">Penerbit</label>
                            <input class="form-control" value="<?php echo e(old('penerbit')); ?>" type="text" name="penerbit"
                                id="penerbit" placeholder="Masukkan Penerbit">
                            <?php $__errorArgs = ['penerbit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($errors->first('penerbit')); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="pengarang">Pengarang</label>
                            <input class="form-control" value="<?php echo e(old('pengarang')); ?>" type="text" name="pengarang"
                                id="pengarang" placeholder="Masukkan Pengarang">
                            <?php $__errorArgs = ['pengarang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($errors->first('pengarang')); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="tahun">Tahun</label>
                            <input class="form-control" value="<?php echo e(old('tahun')); ?>" type="number" name="tahun"
                                id="tahun" placeholder="Masukkan Tahun">
                            <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($errors->first('tahun')); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <input class="form-control" value="<?php echo e(old('deskripsi')); ?>" type="text" name="deskripsi"
                                id="deskripsi" placeholder="Masukkan Deskripsi">
                            <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($errors->first('deskripsi')); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <button class="btn btn-success mt-4">Simpan</button>
            </div>
        </div>
    </form>

    <div class="card mb-4">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul</th>
                        <th>Penerbit</th>
                        <th>Pengarang</th>
                        <th>Tahun</th>
                        <th>Deskripsi</th>
                        <th style="min-width: 150px;width:150px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $i = 1;
                    ?>
                    <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($b->judul); ?></td>
                            <td><?php echo e($b->penerbit); ?></td>
                            <td><?php echo e($b->pengarang); ?></td>
                            <td><?php echo e($b->tahun); ?></td>
                            <td><?php echo e($b->deskripsi); ?></td>
                            <td>
                                <a href="<?php echo e(route('buku.edit', ['buku' => $b->id])); ?>"
                                    class="btn btn-sm btn-warning text-white">Edit</a>
                                <form method="POST" action="<?php echo e(route('buku.destroy', ['buku' => $b->id])); ?>"
                                    class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button href="<?php echo e(route('buku.edit', ['buku' => $b->id])); ?>"
                                        class="btn btn-sm btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git Projects\aplikasi_perpustakaan\resources\views/buku/index.blade.php ENDPATH**/ ?>