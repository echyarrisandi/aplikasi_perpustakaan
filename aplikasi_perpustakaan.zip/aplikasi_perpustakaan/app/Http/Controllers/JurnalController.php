<?php

namespace App\Http\Controllers;

use App\Models\Jurnal;
use Illuminate\Http\Request;

class JurnalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $jurnal = Jurnal::all();
        return view('jurnal.index',compact('jurnal'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('jurnal.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'judul' => 'required',
            'tahun' => 'required',
            'institusi' => 'required',
            'peneliti' => 'required',
            'deskripsi' => 'required',
        ]);

        $jurnal = new Jurnal();
        $jurnal->judul = $request->judul;
        $jurnal->tahun = $request->tahun;
        $jurnal->institusi = $request->institusi;
        $jurnal->peneliti = $request->peneliti;
        $jurnal->deskripsi = $request->deskripsi;
        $jurnal->save();

        return redirect()->route('jurnal.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Jurnal  $jurnal
     * @return \Illuminate\Http\Response
     */
    public function show(Jurnal $jurnal)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Jurnal  $jurnal
     * @return \Illuminate\Http\Response
     */
    public function edit(Jurnal $jurnal)
    {
        return view('jurnal.edit',compact('jurnal'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Jurnal  $jurnal
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Jurnal $jurnal)
    {
        $request->validate([
            'judul' => 'required',
            'tahun' => 'required',
            'institusi' => 'required',
            'peneliti' => 'required',
            'deskripsi' => 'required',
        ]);

        $jurnal->judul = $request->judul;
        $jurnal->tahun = $request->tahun;
        $jurnal->institusi = $request->institusi;
        $jurnal->peneliti = $request->peneliti;
        $jurnal->deskripsi = $request->deskripsi;
        $jurnal->save();

        return redirect()->route('jurnal.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Jurnal  $jurnal
     * @return \Illuminate\Http\Response
     */
    public function destroy(Jurnal $jurnal)
    {
        $jurnal->delete();
        return redirect()->route('jurnal.index');
    }
}
