@extends('layouts.index')

@section('content')
    <form method="POST" action="{{ route('jurnal.store') }}">
        @csrf
        <div class="card mb-4">
            <div class="card-body">
                <h6 class="card-title mb-3">Tambah Jurnal</h6>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="judul">Judul</label>
                            <input class="form-control" value="{{ old('judul') }}" type="text" name="judul"
                                id="judul" placeholder="Masukkan Judul">
                            @error('judul')
                                <small class="text-danger">{{ $errors->first('judul') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="tahun">Tahun</label>
                            <input class="form-control" value="{{ old('tahun') }}" type="text" name="tahun"
                                id="tahun" placeholder="Masukkan Tahun">
                            @error('tahun')
                                <small class="text-danger">{{ $errors->first('tahun') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="institusi">Institusi</label>
                            <input class="form-control" value="{{ old('institusi') }}" type="text" name="institusi"
                                id="institusi" placeholder="Masukkan Institusi">
                            @error('institusi')
                                <small class="text-danger">{{ $errors->first('institusi') }}</small>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="peneliti">Peneliti</label>
                            <input class="form-control" value="{{ old('peneliti') }}" type="number" name="peneliti"
                                id="peneliti" placeholder="Masukkan Peneliti">
                            @error('peneliti')
                                <small class="text-danger">{{ $errors->first('peneliti') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <input class="form-control" value="{{ old('deskripsi') }}" type="text" name="deskripsi"
                                id="deskripsi" placeholder="Masukkan Deskripsi">
                            @error('deskripsi')
                                <small class="text-danger">{{ $errors->first('deskripsi') }}</small>
                            @enderror
                        </div>
                    </div>
                </div>
                <button class="btn btn-success mt-4">Simpan</button>
            </div>
        </div>
    </form>

    <div class="card mb-4">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul</th>
                        <th>Tahun</th>
                        <th>Institusi</th>
                        <th>Peneliti</th>
                        <th>Deskripsi</th>
                        <th style="min-width: 150px;width:150px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $i = 1;
                    @endphp
                    @foreach ($jurnal as $b)
                        <tr>
                            <td>{{ $i++ }}</td>
                            <td>{{ $b->judul }}</td>
                            <td>{{ $b->tahun }}</td>
                            <td>{{ $b->institusi }}</td>
                            <td>{{ $b->peneliti }}</td>
                            <td>{{ $b->deskripsi }}</td>
                            <td>
                                <a href="{{ route('jurnal.edit', ['jurnal' => $b->id]) }}"
                                    class="btn btn-sm btn-warning text-white">Edit</a>
                                <form method="POST" action="{{ route('jurnal.destroy', ['jurnal' => $b->id]) }}"
                                    class="d-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button href="{{ route('jurnal.edit', ['jurnal' => $b->id]) }}"
                                        class="btn btn-sm btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
