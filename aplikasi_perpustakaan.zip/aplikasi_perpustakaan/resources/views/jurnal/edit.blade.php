@extends('layouts.index')

@section('content')
    <form method="POST" action="{{ route('jurnal.update', ['jurnal' => $jurnal->id]) }}">
        @csrf
        @method('PUT')
        <div class="card mb-4">
            <div class="card-body">
                <h6 class="card-title mb-3">Edit Jurnal</h6>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="judul">Judul</label>
                            <input class="form-control" value="{{ old('judul') ? old('judul') : $jurnal->judul }}"
                                type="text" name="judul" id="judul" placeholder="Masukkan Judul">
                            @error('judul')
                                <small class="text-danger">{{ $errors->first('judul') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="tahun">Tahun</label>
                            <input class="form-control" value="{{ old('tahun') ? old('tahun') : $jurnal->tahun }}"
                                type="number" name="tahun" id="tahun" placeholder="Masukkan Tahun">
                            @error('tahun')
                                <small class="text-danger">{{ $errors->first('tahun') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="institusi">Institusi</label>
                            <input class="form-control"
                                value="{{ old('institusi') ? old('institusi') : $jurnal->institusi }}" type="text"
                                name="institusi" id="institusi" placeholder="Masukkan Institusi">
                            @error('institusi')
                                <small class="text-danger">{{ $errors->first('institusi') }}</small>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="peneliti">Peneliti</label>
                            <input class="form-control" value="{{ old('peneliti') ? old('peneliti') : $jurnal->peneliti }}"
                                type="number" name="peneliti" id="peneliti" placeholder="Masukkan Peneliti">
                            @error('peneliti')
                                <small class="text-danger">{{ $errors->first('peneliti') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <input class="form-control"
                                value="{{ old('deskripsi') ? old('deskripsi') : $jurnal->deskripsi }}" type="text"
                                name="deskripsi" id="deskripsi" placeholder="Masukkan Deskripsi">
                            @error('deskripsi')
                                <small class="text-danger">{{ $errors->first('deskripsi') }}</small>
                            @enderror
                        </div>
                    </div>
                </div>
                <a href="{{ route('jurnal.index') }}" class="btn btn-outline-secondary mt-4">Kembali</a>
                <button class="btn btn-warning text-white mt-4">Edit</button>
            </div>
        </div>
    </form>
@endsection
