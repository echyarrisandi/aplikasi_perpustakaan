@extends('layouts.index')

@section('content')
    <form method="POST" action="{{ route('buku.update', ['buku' => $buku->id]) }}">
        @csrf
        @method('PUT')
        <div class="card mb-4">
            <div class="card-body">
                <h6 class="card-title mb-3">Edit Buku</h6>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="judul">Judul</label>
                            <input class="form-control" value="{{ old('judul') ? old('judul') : $buku->judul }}"
                                type="text" name="judul" id="judul" placeholder="Masukkan Judul">
                            @error('judul')
                                <small class="text-danger">{{ $errors->first('judul') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="penerbit">Penerbit</label>
                            <input class="form-control" value="{{ old('penerbit') ? old('penerbit') : $buku->penerbit }}"
                                type="text" name="penerbit" id="penerbit" placeholder="Masukkan Penerbit">
                            @error('penerbit')
                                <small class="text-danger">{{ $errors->first('penerbit') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="pengarang">Pengarang</label>
                            <input class="form-control" value="{{ old('pengarang') ? old('pengarang') : $buku->pengarang }}"
                                type="text" name="pengarang" id="pengarang" placeholder="Masukkan Pengarang">
                            @error('pengarang')
                                <small class="text-danger">{{ $errors->first('pengarang') }}</small>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="tahun">Tahun</label>
                            <input class="form-control" value="{{ old('tahun') ? old('tahun') : $buku->tahun }}"
                                type="number" name="tahun" id="tahun" placeholder="Masukkan Tahun">
                            @error('tahun')
                                <small class="text-danger">{{ $errors->first('tahun') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <input class="form-control" value="{{ old('deskripsi') ? old('deskripsi') : $buku->deskripsi }}"
                                type="text" name="deskripsi" id="deskripsi" placeholder="Masukkan Deskripsi">
                            @error('deskripsi')
                                <small class="text-danger">{{ $errors->first('deskripsi') }}</small>
                            @enderror
                        </div>
                    </div>
                </div>
                <a href="{{ route('buku.index') }}" class="btn btn-outline-secondary mt-4">Kembali</a>
                <button class="btn btn-warning text-white mt-4">Edit</button>
            </div>
        </div>
    </form>
@endsection
