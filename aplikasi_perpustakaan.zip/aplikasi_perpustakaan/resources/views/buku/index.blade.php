@extends('layouts.index')

@section('content')
    <form method="POST" action="{{ route('buku.store') }}">
        @csrf
        <div class="card mb-4">
            <div class="card-body">
                <h6 class="card-title mb-3">Tambah Buku</h6>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="judul">Judul</label>
                            <input class="form-control" value="{{ old('judul') }}" type="text" name="judul"
                                id="judul" placeholder="Masukkan Judul">
                            @error('judul')
                                <small class="text-danger">{{ $errors->first('judul') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="penerbit">Penerbit</label>
                            <input class="form-control" value="{{ old('penerbit') }}" type="text" name="penerbit"
                                id="penerbit" placeholder="Masukkan Penerbit">
                            @error('penerbit')
                                <small class="text-danger">{{ $errors->first('penerbit') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="pengarang">Pengarang</label>
                            <input class="form-control" value="{{ old('pengarang') }}" type="text" name="pengarang"
                                id="pengarang" placeholder="Masukkan Pengarang">
                            @error('pengarang')
                                <small class="text-danger">{{ $errors->first('pengarang') }}</small>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="tahun">Tahun</label>
                            <input class="form-control" value="{{ old('tahun') }}" type="number" name="tahun"
                                id="tahun" placeholder="Masukkan Tahun">
                            @error('tahun')
                                <small class="text-danger">{{ $errors->first('tahun') }}</small>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <input class="form-control" value="{{ old('deskripsi') }}" type="text" name="deskripsi"
                                id="deskripsi" placeholder="Masukkan Deskripsi">
                            @error('deskripsi')
                                <small class="text-danger">{{ $errors->first('deskripsi') }}</small>
                            @enderror
                        </div>
                    </div>
                </div>
                <button class="btn btn-success mt-4">Simpan</button>
            </div>
        </div>
    </form>

    <div class="card mb-4">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul</th>
                        <th>Penerbit</th>
                        <th>Pengarang</th>
                        <th>Tahun</th>
                        <th>Deskripsi</th>
                        <th style="min-width: 150px;width:150px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $i = 1;
                    @endphp
                    @foreach ($buku as $b)
                        <tr>
                            <td>{{ $i++ }}</td>
                            <td>{{ $b->judul }}</td>
                            <td>{{ $b->penerbit }}</td>
                            <td>{{ $b->pengarang }}</td>
                            <td>{{ $b->tahun }}</td>
                            <td>{{ $b->deskripsi }}</td>
                            <td>
                                <a href="{{ route('buku.edit', ['buku' => $b->id]) }}"
                                    class="btn btn-sm btn-warning text-white">Edit</a>
                                <form method="POST" action="{{ route('buku.destroy', ['buku' => $b->id]) }}"
                                    class="d-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button href="{{ route('buku.edit', ['buku' => $b->id]) }}"
                                        class="btn btn-sm btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
