@extends('layouts.index')

@section('content')
    <p class="text-center lead mt-5 pt-5">Selamat datang pada aplikasi perpustakaan!</p>
@endsection